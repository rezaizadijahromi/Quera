class FactorHandler:

    def __init__(self):
        pass

    def add_factor(self, time_format, time, value):
        pass

    def remove_all_factors(self, time_format, time):
        pass

    def get_sum(self, time_format, start_time, finish_time):
        pass
