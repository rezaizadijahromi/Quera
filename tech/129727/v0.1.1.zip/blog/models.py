
from django.utils import timezone
from django.db import models
from account.models import User

STATUS_CHOICES = (
    ("d", "draft"),
    ("p", "publish ")
)


class Category(models.Model):
    title = models.CharField(max_length=50)
    status = models.BooleanField(default=True)

    def __str__(self):
        return str(self.id)


class Article(models.Model):
    author = models.ForeignKey(
        User, on_delete=models.CASCADE, null=True, default="", blank=True)
    category = models.ForeignKey(
        "Category", on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=100)
    body = models.TextField()
    updated = models.DateTimeField(auto_now=True)
    created = models.DateTimeField(auto_now_add=True)
    published = models.DateTimeField(default=timezone.now)
    status = models.CharField(
        max_length=1, choices=STATUS_CHOICES, default="p")

    def __str__(self):
        return str(self.author)
