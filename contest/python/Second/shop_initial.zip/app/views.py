def checkout(request, order_pk):
    pass

